<div class="well">
	Sidebar Module Placeholder
</div>