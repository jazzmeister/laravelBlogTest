@extends('layouts.master')

@section('content')

Welcome to our test Blog built on Laravel!<br>

Use the nav on the left to see all posts, by all users.<br>

You can view add and manage your own posts once logged in.<br><br>

{{HTML::image('/assets/images/logo.png')}}

@stop
